// 변수를 선언합니다.
let test;
// 짧은 초기화 조건문1
test = test || "초기화합니다_1"
console.log(test);
// 짧은 초기화 조건문2
test = test || "초기화합니다_2"
console.log(test);