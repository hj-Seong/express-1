let input = 32;
if (input % 2 == 0) {
    console.log("짝수입니다!");
}
if (input % 2 == 1) {
    console.log("홀수입니다!");
}