// 변수를 선언합니다.
let numberA = 52;
let numberB = 0;
let numberC = -23;
// 조건을 구분합니다.
console.log(`${numberA}은/는 ${numberA > 0 ? "0보다 큰" : "0 또는 0보다 작은"} 숫자입니다.`);
console.log(`${numberB}은/는 ${numberB > 0 ? "0보다 큰" : "0 또는 0보다 작은"} 숫자입니다.`);
console.log(`${numberC}은/는 ${numberC > 0 ? "0보다 큰" : "0 또는 0보다 작은"} 숫자입니다.`);