let input = 32;
if (input % 2 == 0) {
    console.log("짝수입니다!");
} else {
    console.log("홀수입니다!");
}