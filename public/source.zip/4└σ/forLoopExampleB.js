// 변수를 선언합니다.
let output = 1; 
// 반복을 수행합니다.
for (let i = 1; i <= 20; i++) {
    output *= i;
}
// 출력합니다.
console.log(output);