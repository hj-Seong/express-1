// 변수를 선언합니다.
let i = 0;
let array = [52, 273, 32, 65, 103];
// 반복을 수행합니다.
while (i < array.length) {
    // 출력합니다.
    console.log(i + "번째 출력:" + array[i]);
    // 탈출하려고 변수를 더합니다.
    i++;
}