// 변수를 선언합니다.
let output = 0;
// 반복을 수행합니다.
for (let i = 0; i <= 100; i++) {
    output += i;
}
// 출력합니다.
console.log(output);