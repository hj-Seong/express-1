// 배열을 생성합니다.
let array = [1, 2, 3, 4, 5, 6];
// 요소의 길이를 출력합니다.
for (let i = array.length - 1; i >= 0; i--) {
    console.log(array[i]);
}