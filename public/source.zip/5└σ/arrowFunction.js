let 함수 = () => {
    console.log("함수의 첫 번째 줄");
    console.log("함수의 두 번째 줄");
}; 
함수(); 
console.log(함수);