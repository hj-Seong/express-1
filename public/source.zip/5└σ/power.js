function power(x) {
    return x * x;
}
console.log(power(10));
console.log(power(20));