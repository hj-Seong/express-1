// 변수를 생성합니다.
let primitiveNumber = 273;
// 메소드를 추가합니다.
Number.prototype.method = function () {
    return 'Primitive Method';
};
// 메소드를 실행합니다.
console.log(primitiveNumber.method());