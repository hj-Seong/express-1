// 변수를 선언합니다.
let number = 273.5210332;
// 출력합니다.
console.log(number.toFixed(1));
console.log(number.toFixed(4));