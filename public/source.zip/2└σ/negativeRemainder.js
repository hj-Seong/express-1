console.log(4 % 3);
console.log(-4 % 3);
console.log(4 % -3);
console.log(-4 % -3);