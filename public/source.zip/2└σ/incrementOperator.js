let number = 10;
number++;
console.log(number);
number--;
console.log(number);