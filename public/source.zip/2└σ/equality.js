console.log(`52 == "52": ${52 == "52"}`);
console.log(`52 === "52": ${52 === "52"}`);
console.log();
console.log(`0 == "": ${0 == ""}`);
console.log(`0 === "": ${0 === ""}`);