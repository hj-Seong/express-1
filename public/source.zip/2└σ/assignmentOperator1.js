let output = 0;
output += 52;
output += 273;
output += 103;
console.log(output);