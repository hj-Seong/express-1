console.log(!true);
console.log(!false);
console.log(!(52 < 273))
console.log(!(52 > 273))