let output = 0;
output = output + 52;
output = output + 273;
output = output + 103;
console.log(output);