let output = "hello ";
output += "world ";
output += "!";
console.log(output);