let hours = (new Date()).getHours();
console.log(hours < 3 || 8 < hours);
console.log(3 <= hours && hours <= 8);