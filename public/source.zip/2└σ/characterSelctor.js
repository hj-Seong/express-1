console.log("안녕하세요"[0]);
console.log("안녕하세요"[1]);
console.log("안녕하세요"[3]);
