let number = 10;
console.log(number);
console.log(++number);
console.log(--number);
console.log(number);