// 상수를 선언합니다.
const constant = "변경할 수 없어요";
constant = "";
// 출력합니다.
console.log(constant);