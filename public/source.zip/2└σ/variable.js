let pi = 3.14159265;
let radius = 10;
console.log(`둘레: ${2 * pi * radius}`);
console.log(`넓이: ${pi * radius * radius}`);