// 객체를 선언합니다.
let product = {
    제품명: '7D 건조 망고',
    유형: '당절임',
    성분: '망고, 설탕, 메타중아황산나트륨, 치자황색소',
    원산지: '필리핀'
};
// 출력합니다.
console.log(product);

// 객체를 선언합니다.
let object = {
    name: '바나나',
    price: 1200
};
// 출력합니다.
console.log(object.name);
console.log(object.price);